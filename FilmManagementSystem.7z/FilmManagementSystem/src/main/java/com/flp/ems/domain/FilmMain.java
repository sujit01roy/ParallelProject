package com.flp.ems.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FilmMain {

	public static void main(String[] args) {
		Date date=new Date();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		FilmService service=new FilmService(em);
		em.getTransaction().begin();
		
		
		
		Image img1=service.createImage(101,"John.jpg",null, date);
		Image img2=service.createImage(102,"Abhishek.jpg",null,date);
		Image img3=service.createImage(103,"Salman.jpg",null, date);
		
		List<Image> imgList1=new ArrayList<Image>();
		
		imgList1.add(img1);
		imgList1.add(img2);
		imgList1.add(img3);
		
		Image img11=service.createImage(104,"John.jpg",null, date);
		Image img22=service.createImage(105,"Abhishek.jpg",null,date);
		Image img33=service.createImage(106,"Salman.jpg",null, date);
		
		
		List<Image> imgList2=new ArrayList<Image>();
		imgList2.add(img11);
		imgList2.add(img22);
		imgList2.add(img33);
		
		
		
						
		Album alb1=service.createAlbum(201,"FilmAlbum1",imgList1,null, date);
		Album alb2=service.createAlbum(202,"FilmAlbum2", imgList2,null, date);
		
		
		
		
		Category ctg1=service.createCategory(301,"Action",null,date);
		Category ctg2=service.createCategory(303,"Adventure",null,date);
		
		List<Category> category=new ArrayList<Category>();
		
		category.add(ctg1);
		category.add(ctg2);
			
		
		
				
		Actor act1=service.createActor(405,"John", "Abraham","Male", alb1,null,date);
		Actor act2=service.createActor(410,"Salman", "khan","Male",alb2,null,date);
		Actor act3=service.createActor(407,"Shahrukh", "khan","Male",alb2,null,date);
		
		List<Actor> actor1=new ArrayList<Actor>();
		
		actor1.add(act1);
		actor1.add(act2);
		
		List<Actor> actor2=new ArrayList<Actor>();
		
		actor2.add(act1);
		actor2.add(act3);
		
		Film flm1=service.createFilm(501,"Dhoom", "Action",(short) 2010, alb1, "Hindi", actor1, category, (byte)4, date);
		Film flm2=service.createFilm(502,"Don", "Action",(short)2012, alb2, "Hindi", actor2, category, (byte)4, date);
		
		List<Film> films=new ArrayList<Film>();
		    films.add(flm1);
		    films.add(flm2);
		    
		    em.getTransaction().commit();
		
		    em.close();
			emf.close();
		
	}

}
