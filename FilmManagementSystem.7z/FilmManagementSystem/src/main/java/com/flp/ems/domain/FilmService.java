package com.flp.ems.domain;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;



public class FilmService {

	protected EntityManager em;
	
	public FilmService(EntityManager em){
		this.em=em;
	}
	
public Film createFilm(int id,String title,String description, Short releaseYear,Album album,String language,List<Actor>actor,List<Category>category, byte rating, Date deleteDate){
		
		Film flm = new Film(id);
		
		flm.setTitle(title);
		flm.setDescription(description);
		flm.setReleaseYear(releaseYear);
		flm.setAlbum(album);
		flm.setLanguage(language);
		flm.setActor(actor);
		flm.setCategory(category);
		flm.setRating(rating);
		flm.setDeleteDate(deleteDate);
		em.persist(flm);
		return flm;
	}


public Category createCategory(int id,String name,Date createDate,Date deleteDate){
	
	Category ctg=new Category(id);
	
	ctg.setName(name);
	ctg.setCreateDate(createDate);
	ctg.setDeleteDate(deleteDate);
	em.persist(ctg);
	return ctg;
	
}

public Actor createActor(int id,String firstName,String lastName,String gender,Album album,Date createDate,Date deleteDate){
	
	Actor act=new Actor();
	
	act.setFirstName(firstName);
	act.setLastName(lastName);
	act.setGender(gender);
	act.setId(id);
	act.setAlbum(album);
	act.setCreateDate(createDate);
	act.setDeleteDate(deleteDate);
	em.persist(act);
	return act;
	
	
	
}

public Album createAlbum(int id,String albumName, List<Image>image,Date createDate,Date deleteDate){
	
	Album alb=new Album(id);
	
	alb.setAlbumName(albumName);
	alb.setImage(image);
	alb.setCreateDate(createDate);
	alb.setDeleteDate(deleteDate);
	
	em.persist(alb);
	return alb;
}

public Image createImage(int id,String imageUrl,Date createDate,Date deleteDate){
	
	Image img=new Image(id);
	
	img.setImageUrl(imageUrl);
	img.setCreateDate(createDate);
	img.setDeleteDate(deleteDate);
	em.persist(img);
	return img;
}

 public Actor findActor(int id) {
	// TODO Auto-generated method stub
	return em.find(Actor.class, id);
}

 public Category findCategory(int id) {
	// TODO Auto-generated method stub
	return em.find(Category.class, id);
}
 
 public Actor setFilmOnActor(int id,List<Film>films){
		Actor a = findActor(id);
		a.setFilm(films);
		em.persist(a);
		return a;
	} 
 

 
 public Category setFilmsOnCategory(int id, List<Film>films){
		Category c = findCategory(id);
		c.setFilm(films);
		em.persist(c);
		return c;
	}


}
