package com.flp.ems.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;



@Entity
public class Category {
	
	@Id private int id;
	private String name;
	private Date createDate;
	private Date deleteDate;
	@ManyToMany
	
	private List<Film>film;
	
	
	
	public List<Film> getFilm() {
		return film;
	}

	public void setFilm(List<Film> film) {
		this.film = film;
	}

	public Category(){
		
		super();
	}
	
	public Category(int id){
		super();
		this.id=id;
	}
	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public Date getCreateDate() {
		return createDate;
	}




	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}




	public Date getDeleteDate() {
		return deleteDate;
	}




	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}




	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", createDate=" + createDate + ", deleteDate=" + deleteDate
				+ "]";
	}
	

}
