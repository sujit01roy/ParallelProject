package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;

public interface IFilmDAO {
	public Film addFilm(Film film);
	
	public String updateFilm(Film film);
	
	public String removeFilm(Film film);
	
	public List<Film> searchFilmByTitle(String title);
	
	public List<Film> searchFilmByRating(byte rating);
	
	public List<Film> searchFilmByActor(Actor actor);
	
	public List<Film> searchFilmByCategory(Category category);
	
	public List<Film> searchFilmByLanguage(String language);
	
	public List<Film> getAllFilm(List<Film> film);
}
