package com.flp.fms.demoApplication;

import javax.persistence.EntityManager;

public class Service {
protected EntityManager em;
	
	public Service(EntityManager em){
		this.em=em;
	}

}
