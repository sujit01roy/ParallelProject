package com.flp.fms.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.flp.fms.domain.Album;
import com.flp.fms.domain.Image;

public class AlbumService {
protected EntityManager em;
	
	public AlbumService(EntityManager em){
		this.em=em;
	}
	
	
}
