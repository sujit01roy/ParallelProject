package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Album;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Image;
import com.flp.fms.service.FilmServiceImpl;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		//FilmServiceImpl service = new FilmServiceImpl(em);
//		Image i=new Image();
//		em.getTransaction().begin();
//		Image image1 = service.createImage(1,"airlift.jpg",null,null);
//		Image image2=service.createImage(2,"airlift1.jpg",null,null);
//		List<Image> imageList = new ArrayList<Image>();
//		imageList.add(image1);
//		imageList.add(image2);
//		List<Album> album = new ArrayList<Album>();
//		Album album1=service.createAlbum(1, "AirLift", imageList, null, null);
//		
//		Actor actor1=service.createActor(1, "Akshay", "Kumar", "Male", album1, null, null);
//		List<Actor> actorList=new ArrayList<Actor>();
//		
//		Category category1=service.createCategory(1, "Action", null, null);
//		Category category2=service.createCategory(2, "Drama", null, null);
//		List<Category> categoryList=new ArrayList<Category>();
//		
		//System.out.println(service.addFilm(new Film(1,"DDLJ","Gud",null,album1,"Hindi",actorList,categoryList,(byte)4,null,(short) 140,new Date())));
		em.getTransaction().commit();
		em.close();
		emf.close();
		

	}

}
