package com.flp.fms.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import com.flp.fms.dao.ActorDAOImpl;
import com.flp.fms.dao.FilmDAOImpl;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Album;
import com.flp.fms.domain.Film;

public class ActorServiceImpl implements IActorService {
protected EntityManager em;
protected ActorDAOImpl actorDao;
	
	public ActorServiceImpl(EntityManager em){
		this.em=em;
	}
	
	public ActorServiceImpl(ActorDAOImpl actorDao) {
		super();
		this.actorDao = actorDao;
	}

	public Actor addActor(Actor actor){
		return actorDao.addActor(actor);
	}

	public List<Actor> searchActorByName(String name) {
		return actorDao.findActorByName(name);
	}

	public String removeActor(Actor actor) {
		return actorDao.deleteeActor(actor);
	}

	public Actor modifyActor(Actor actor) {
		return actorDao.updateActor(actor);
	}

	public List<Actor> searchActorByGender(String gender) {
		return actorDao.findActorByGender(gender);
	}	
	
}
