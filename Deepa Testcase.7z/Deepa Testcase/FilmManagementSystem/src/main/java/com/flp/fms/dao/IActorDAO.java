package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorDAO {
	Actor addActor(Actor actor);
	
	List<Actor> findActorByName(String name);
	
	List<Actor> findActorByGender(String gender);
	
	String deleteeActor(Actor actor);
	
	Actor updateActor(Actor actor);
}
