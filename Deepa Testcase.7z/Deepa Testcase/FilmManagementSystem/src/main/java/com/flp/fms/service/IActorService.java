package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorService {
	Actor addActor(Actor actor);
	
	List<Actor> searchActorByName(String name);
	
	List<Actor> searchActorByGender(String gender);
	
	String removeActor(Actor actor);
	
	Actor modifyActor(Actor actor);
}
