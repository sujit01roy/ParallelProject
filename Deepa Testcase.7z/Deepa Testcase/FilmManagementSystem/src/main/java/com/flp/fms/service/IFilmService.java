package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;

public interface IFilmService {
	String addFilm(Film film);
	
	List<Film> searchFilmByTitle(String title);
	
	List<Film> searchFilmByRating(byte rating);
	
	List<Film> searchFilmByActor(Actor actor);
	
	List<Film> searchFilmByCategory(Category category);
	
	List<Film> searchFilmByLanguage(String language);
	
	String modifyFilm(Film film);
	
	String deleteFilm(Film film);
	
	List<Film> getAllFilm(List<Film> film);
}

