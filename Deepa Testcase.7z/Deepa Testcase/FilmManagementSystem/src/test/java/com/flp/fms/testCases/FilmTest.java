package com.flp.fms.testCases;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.flp.fms.dao.ActorDAOImpl;
import com.flp.fms.dao.FilmDAOImpl;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;

public class FilmTest {

	private FilmServiceImpl filmService;
	private ActorServiceImpl actorService;
	@Mock
	private FilmDAOImpl filmDao;
	@Mock
	private ActorDAOImpl actorDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		filmService = new FilmServiceImpl(filmDao);
		actorService = new ActorServiceImpl(actorDao);

	}
	// Add Film
	// 1. If any parameter is invalid, value should not be added.
	// 2. If all the input parameters are valid, then the film object should be added.
	// 3. If all the parameters are valid but the film object is not added, then system should throw error.
	// 4. If input is null, it should throw null pointer exception.

	@Test
	public void invalidParameterForFilm() {
		Mockito.when(filmService.addFilm(new Film())).thenReturn(null);
		assertEquals(null, filmService.addFilm(new Film()));
	}

	@Test
	public void validParameterForFilm() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,null);
		Mockito.when(filmService.addFilm(film)).thenReturn("");
		assertEquals("", filmService.addFilm(film));
	}

	@Test
	public void systemErrorForFilm() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		Mockito.when(filmService.addFilm(film)).thenReturn(null);
		assertEquals(null, filmService.addFilm(film));
	}

	@Test(expected=Exception.class)
	public void nullInputShouldThrowException() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,new Date());
		Mockito.when(filmService.addFilm(null)).thenThrow(Exception.class);
		filmService.addFilm(null);
	}

	// Search By Title
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=Exception.class)
	public void nullInputShouldNotSearchByTitle() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByTitle(null)).thenThrow(Exception.class);
		filmService.searchFilmByTitle(null);
	}

	@Test
	public void invalidInputShouldNotSearchByTitle() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByTitle("KK")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByTitle("KK"));
	}

	@Test
	public void validInputShouldSearchByTitle() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByTitle("DDLJ")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByTitle("DDLJ"));
	}

	@Test
	public void validInputShouldNotSearchByTitle() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByTitle("DDLJ")).thenReturn(null);
		assertEquals(null, filmService.searchFilmByTitle("DDLJ"));
	}

	// Search By Language
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, thenn it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByLanguage() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByLanguage(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByLanguage(null);
	}

	@Test
	public void invalidInputShouldNotSearchByLanguage() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByLanguage("Marathi")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByLanguage("Marathi"));
	}

	@Test
	public void validInputShouldSearchByLanguage() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByLanguage("Hindi")).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByLanguage("Hindi"));
	}

	@Test
	public void validInputShouldNotSearchByLanguage() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByLanguage("Hindi")).thenReturn(null);
		assertEquals(null, filmService.searchFilmByLanguage("Hindi"));
	}

	// Search By Rating
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByRating() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		try {
			Mockito.when(filmService.searchFilmByRating(new Byte(null))).thenThrow(NullPointerException.class);
			filmService.searchFilmByRating(new Byte(null));
		} catch (IllegalArgumentException iae) {
		}
	}

	@Test
	public void invalidInputShouldNotSearchByRating() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByRating((byte) 10)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByRating((byte) 10));
	}

	@Test
	public void validInputShouldSearchByRating() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByRating((byte) 4)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByRating((byte) 4));
	}

	@Test
	public void validInputShouldNotSearchByRating() {
		Film film = new Film(1, "DDLJ", "Gud", null, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByRating((byte) 4)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByRating((byte) 4));
	}

	// Search By Release Year
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByReleaseYear() {
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByReleaseYear(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByReleaseYear(null);
	}

	@Test
	public void invalidInputShouldNotSearchByReleaseYear() {
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

		String input = "1818-11-11";
		try {
			Mockito.when(filmService.searchFilmByReleaseYear(ft.parse(input))).thenReturn(filmList);

			assertEquals(filmList, filmService.searchFilmByReleaseYear(ft.parse(input)));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void validInputShouldSearchByReleaseYear() {
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByReleaseYear(new Date())).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByReleaseYear(new Date()));
	}

	@Test
	public void validInputShouldNotSearchByReleaseYear() {
		Date date = new Date();
		Film film = new Film(1, "DDLJ", "Gud", date, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByReleaseYear(date)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByReleaseYear(date));
	}

	// Search By Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByActor(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByActor(null);
	}

	@Test
	public void invalidInputShouldNotSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		Actor actor2 = filmService.createActor(2, "Madhvan", "R", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", actorList, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmService.searchFilmByActor(actor2)).thenReturn(filmList);

		assertEquals(filmList, filmService.searchFilmByActor(actor2));
	}

	@Test
	public void validInputShouldSearchByActor() {
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", actorList, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByActor(actor1)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByActor(actor1));
	}

	@Test
	public void validInputShouldNotSearchByActor() {
		Date date = new Date();
		Actor actor1 = filmService.createActor(1, "Akshay", "Kumar", "Male", null, null, null);
		List<Actor> actorList = new ArrayList<Actor>();
		actorList.add(actor1);
		Film film = new Film(1, "DDLJ", "Gud", date, null, "Hindi", null, null, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByActor(actor1)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByActor(actor1));
	}

	// Search By Category
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=NullPointerException.class)
	public void nullInputShouldNotSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByCategory(null)).thenThrow(NullPointerException.class);
		filmService.searchFilmByCategory(null);
	}

	@Test
	public void invalidInputShouldNotSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmService.searchFilmByCategory(category)).thenReturn(filmList);

		assertEquals(filmList, filmService.searchFilmByCategory(category));
	}

	@Test
	public void validInputShouldSearchByCategory() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByCategory(category)).thenReturn(filmList);
		assertEquals(filmList, filmService.searchFilmByCategory(category));
	}

	@Test
	public void validInputShouldNotSearchByCategory() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", date, null, "Hindi", null, categoryList, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.searchFilmByCategory(category)).thenReturn(null);
		assertEquals(null, filmService.searchFilmByCategory(category));
	}

	// Modify Film
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=Exception.class)
	public void nullInputShouldNotModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.modifyFilm(null)).thenThrow(Exception.class);
		filmService.modifyFilm(film);
	}

	@Test
	public void invalidInputShouldNotModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmService.modifyFilm(film)).thenReturn("");

		assertEquals("", filmService.modifyFilm(film));
	}

	@Test
	public void validInputShouldModifyFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.modifyFilm(film)).thenReturn("");
		assertEquals("", filmService.modifyFilm(film));
	}

	@Test
	public void validInputShouldNotModifyFilm() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", date, null, "Hindi", null, categoryList, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.modifyFilm(film)).thenReturn(null);
		assertEquals(null, filmService.modifyFilm(film));
	}

	// Delete Film
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test(expected=Exception.class)
	public void nullInputShouldNotDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.deleteFilm(null)).thenThrow(Exception.class);
		filmService.deleteFilm(film);
	
	}

	@Test
	public void invalidInputShouldNotDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);

		Mockito.when(filmService.deleteFilm(film)).thenReturn("");

		assertEquals("", filmService.deleteFilm(film));
	}

	@Test
	public void validInputShouldDeleteFilm() {
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", new Date(), null, "Hindi", null, categoryList, (byte) 4, null,
				(short) 140, new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.deleteFilm(film)).thenReturn("");
		assertEquals("", filmService.deleteFilm(film));
	}

	@Test
	public void validInputShouldNotDeleteFilm() {
		Date date = new Date();
		Category category = filmService.createCategory(1, "Action", null, null);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		Film film = new Film(1, "DDLJ", "Gud", date, null, "Hindi", null, categoryList, (byte) 4, null, (short) 140,
				new Date());
		List<Film> filmList = new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(filmService.deleteFilm(film)).thenReturn(null);
		assertEquals(null, filmService.deleteFilm(film));
	}

	// Add Actor
	// 1. If any parameter is invalid, value should not be added.
	// 2. If all the input parameters are valid, then the film object should be added.
	// 3. If all the parameters are valid but the film object is not added, then system should throw error.

	@Test
	public void invalidParameterForActor() {
		Actor actor = new Actor();
		Mockito.when(actorService.addActor(new Actor())).thenReturn(null);
		assertEquals(null, actorService.addActor(new Actor()));
	}

	@Test
	public void validParameterForActor() {
		Actor actor = new Actor();
		Mockito.when(actorService.addActor(actor)).thenReturn(actor);
		assertEquals(actor, actorService.addActor(actor));
	}

	@Test
	public void systemErrorForActor() {
		Actor actor = new Actor();
		Mockito.when(actorService.addActor(actor)).thenReturn(null);
		assertEquals(null, actorService.addActor(actor));
	}

	// Search By name of Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test
	public void nullInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByName(null)).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByName(null));
	}

	@Test
	public void invalidInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByName("Katrina")).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByName("Katrina"));
	}

	@Test
	public void validInputShouldSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByName("Diya")).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByName("Diya"));
	}

	@Test
	public void validInputShouldNotSearchByname() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByName("Diya")).thenReturn(null);
		assertEquals(null, actorService.searchActorByName("Diya"));
	}

	// Search By gender of Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

	@Test
	public void nullInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByGender(null)).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByGender(null));
	}

	@Test
	public void invalidInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByGender("Male")).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByGender("Male"));
	}

	@Test
	public void validInputShouldSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByGender("Female")).thenReturn(actorList);
		assertEquals(actorList, actorService.searchActorByGender("Female"));
	}

	@Test
	public void validInputShouldNotSearchByGender() {
		Actor actor = new Actor();
		List<Actor> actorList = new ArrayList<Actor>();
		Mockito.when(actorService.searchActorByGender("Female")).thenReturn(null);
		assertEquals(null, actorService.searchActorByGender("Female"));
	}
	
	// Delete Actor
	// 1. If input is null, it should not search.
	// 2. If input value is not present, it should throw error.
	// 3. If input value is present, then it should return film object.
	// 4. If the value is present and the system cannot return the object, then it should show error.

		@Test(expected=NullPointerException.class)
		public void nullInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.removeActor(actor)).thenThrow(NullPointerException.class);
			filmService.deleteFilm(null);
		}

		@Test
		public void invalidInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.removeActor(actor)).thenReturn("Actor cannot be deleted");
			assertEquals("Actor cannot be deleted",actorService.removeActor(actor));
		}

		@Test
		public void validInputShouldDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.removeActor(actor)).thenReturn("Cannot be deleted");
			assertEquals("Cannot be deleted", actorService.removeActor(actor));
		}

		@Test
		public void validInputShouldNotDeleteActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.removeActor(actor)).thenReturn(null);
			assertEquals(null, actorService.removeActor(actor));
		}
		
		// Modify Actor
		// 1. If input is null, it should not search.
		// 2. If input value is not present, it should throw error.
		// 3. If input value is present, then it should return film object.
		// 4. If the value is present and the system cannot return the object, then it should show error.

		@Test
		public void nullInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.modifyActor(null)).thenReturn(actor);
			assertEquals(actor, actorService.modifyActor(null));
		}

		@Test
		public void invalidInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.modifyActor(actor)).thenReturn(actor);

			assertEquals(actor, actorService.modifyActor(actor));
		}

		@Test
		public void validInputShouldModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.modifyActor(actor)).thenReturn(actor);
			assertEquals(actor, actorService.modifyActor(actor));
		}

		@Test
		public void validInputShouldNotModifyActor() {
			Actor actor = new Actor();
			Mockito.when(actorService.modifyActor(actor)).thenReturn(null);
			assertEquals(null, actorService.modifyActor(actor));
		}



}
